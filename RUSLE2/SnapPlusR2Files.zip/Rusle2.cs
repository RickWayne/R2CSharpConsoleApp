﻿using System;
using System.Runtime.InteropServices;
using SnapPlus.Models.Interfaces;

namespace SnapPlus.Models.Erosion
{
    /// <summary>
    /// Interface to the RUSLE2 API. Currently runs with a DLL on same system, and a GDB file using the old SQLite 2 format.
    /// </summary>
    public class Rusle2 : IRusle2
    {
        private IntPtr handle = IntPtr.Zero; // Each instance of the class has its own R2 handle. Hopefully re-entrant?
        private IntPtr database = IntPtr.Zero;
        private IntPtr fileSystemPtr = IntPtr.Zero;
        private IntPtr engine = IntPtr.Zero;
        private UnManStringHeap heap = new UnManStringHeap();

        /// <summary>
        /// Initializes a new instance of the <see cref="Rusle2"/> class.
        /// </summary>
        public Rusle2() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Rusle2"/> class, with an open GDB.
        /// </summary>
        /// <param name="r2Path">Full path to data files, e.g. C:\ProgramData\UWSoils\SnapPlus3\RUSLE2</param>
        /// <param name="r2DatabaseFileName">Name of GDB file, defaults to moses.Snap.gdb</param>
        public bool InitializeAndOpen(string r2Path, string r2DatabaseFileName = "moses.Snap.gdb")
        {
            if (!Init(r2Path)) throw new Exception($"Could not initialize RUSLE2 with path {r2Path}");
            if (!GetDatabase()) throw new Exception($"Could not initialize RUSLE2 database at {r2Path}");
            if (!OpenDatabase(@"{r2path}\{r2DatabaseFileName}")) throw new Exception($"Could not open RUSLE2 database {r2DatabaseFileName} at {r2Path}");
            if (!GetEngine()) throw new Exception($"Could not initialize RUSLE2 engine with path {r2Path}");
            if (!EngineSetAutorun(false)) throw new Exception($"Could not set RUSLE2 engine to autorun=false, path {r2Path}");
            if (!GetFiles()) throw new Exception($"Could not set up for RUSLE2 'files' for {r2DatabaseFileName} at {r2Path}");

            return true;
        }

        public bool isOpen()
        {
            return handle != IntPtr.Zero && database != IntPtr.Zero && fileSystemPtr != IntPtr.Zero;
        }

        /// <summary>
        /// Initialize the RUSLE2 DLL.
        /// </summary>
        /// <param name="r2DataPath">Full path to data files, e.g. C:\ProgramData\UWSoils\SnapPlus3\RUSLE2.</param>
        /// <returns>True if successful.</returns>
        public bool Init(string r2DataPath)
        {
            IntPtr ptr = heap.StringToPtr(r2DataPath);
            handle = Rusle2.RomeInit(ptr);
            return (handle != IntPtr.Zero);
        }

        /// <summary>
        /// RUSLE science version.
        /// </summary>
        /// <returns>The science version as an integer.</returns>
        public int GetScienceVersion()
        {
            return RomeGetScienceVersion(handle);
        }

        /// <summary>
        /// GetDatabase -- initializes the database, but doesn't open it. TODO: Probably unneeded, just call from OpenDatabase.
        /// </summary>
        /// <returns>True if successful.</returns>
        public bool GetDatabase()
        {
            if (handle == IntPtr.Zero)
                return false;
            database = RomeGetDatabase(handle);
            if (database == IntPtr.Zero)
                return false;
            return true;
        }

        /// <summary>
        /// Actually opens the GDB.
        /// </summary>
        /// <param name="path">Full path to the GDB file.</param>
        /// <returns>True if successful.</returns>
        public bool OpenDatabase(string path)
        {
            IntPtr pathPtr = heap.StringToPtr(path);
            return RomeDatabaseOpen(database, pathPtr);
        }

        public bool CloseDatabase()
        {
            return RomeDatabaseClose(database, IntPtr.Zero);
        }
        /// <summary>
        /// Initialize the GDB for "file" access. TODO: This can probably be hidden, and just be
        /// called from FilesOpen.
        /// </summary>
        /// <returns>True if successfull.</returns>
        public bool GetFiles()
        {
            fileSystemPtr = RomeGetFiles(handle);
            if (fileSystemPtr == IntPtr.Zero)
                return false;
            else
                return true;
        }

        /// <summary>
        /// Open a file in the GDB. Depending on how R2 is set up, might actually be one or more
        /// physical files of XML, otherwise get 'em out of the database.
        /// </summary>
        /// <param name="r2FakePath">A string identifying the data, which looks like a file path.</param>
        /// <returns>An IntPtr to the data, to be passed to other R2 functions.</returns>
        public IntPtr FilesOpen(string r2FakePath, int flags = 0)
        {
            if (fileSystemPtr == IntPtr.Zero)
            {
                if (!GetFiles())
                    throw new Exception(@"Could not open R2 'filesystem'");
            }
            IntPtr r2FakePathPtr = heap.StringToPtr(r2FakePath);
            IntPtr fileObj = RomeFilesOpen(fileSystemPtr, r2FakePathPtr, flags);
            return fileObj;
        }

        /// <summary>
        /// Initialize the R2 "engine".
        /// </summary>
        /// <returns>true if successful</returns>
        public bool GetEngine()
        {
            engine = RomeGetEngine(handle);
            if (engine == IntPtr.Zero)
                return false;
            else
                return true;
        }

        // Uses an RT_FILEOBJ
        public bool FileClose(IntPtr fileHandle)
        {
            RomeFileClose(fileHandle);
            return true;
        }
        public bool FilesCloseAll()
        {
            RomeFilesCloseAll(fileSystemPtr, 0); // Second argument ignored
            return true;
        }
        public bool EngineRun()
        {
            return RomeEngineRun(engine);
        }
        public bool EngineGetAutorun()
        {
            return RomeEngineGetAutorun(engine);
        }
        public bool EngineSetAutorun(bool autoRun)
        {
            RomeEngineSetAutorun(engine, autoRun);
            return true;
        }
        public string GetTitle(string key)
        {
            IntPtr keyPtr = heap.StringToPtr(key);
            return heap.PtrToString(RomeGetTitle(handle, keyPtr));
        }
        public IntPtr FileGetAttr(IntPtr fileHandle, string attrName)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            return RomeFileGetAttr(fileHandle, attrNamePtr);
        }
        public int FileGetAttrSize(IntPtr fileHandle, string attrName)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            return RomeFileGetAttrSize(fileHandle, attrNamePtr);
        }
        public string FileGetAttrValue(IntPtr fileHandle, string attrName, int index)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            return heap.PtrToString(RomeFileGetAttrValue(fileHandle, attrNamePtr, index));
        }
        public int FileSetAttrValue(IntPtr fileHandle, string attrName, string value, int index)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            IntPtr attrValuePtr = heap.StringToPtr(value);   // Ditto
            return RomeFileSetAttrValue(fileHandle, attrNamePtr, attrValuePtr, index);
        }

        /// <summary>
        /// Set the root size of an attribute in a file. Create the attr if it doesn't exist (I think.)
        /// </summary>
        /// <param name="fileHandle">Rome file name (e.g. "profiles\default".</param>
        /// <param name="attrName">Duh.</param>
        /// <param name="newSize">Also duh. < 32767.</param>
        /// <returns>1 if successful, 0 if unsuccessful, -1 if error.</returns>
        public int FileSetAttrSize(IntPtr fileHandle, string attrName, int newSize)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            return RomeFileFileSetAttrSize(fileHandle, attrNamePtr, newSize);
        }
        public long FileGetAttrSizeEx(IntPtr fileHandle, string attrName)
        {
            IntPtr attrNamePtr = heap.StringToPtr(attrName); // TODO: Mem leak, figure out how to dispose
            return RomeFileGetAttrSizeEx(fileHandle, attrNamePtr);
        }
        public string GetPropertyStr(int propertyID)
        {
            IntPtr propStringPtr = RomeGetPropertyStr(handle, propertyID);
            return heap.PtrToString(propStringPtr);
        }
        public string GetLastError()
        {
            IntPtr errStringPtr = RomeGetLastError(handle);
            return heap.PtrToString(errStringPtr);
        }
        public bool Exit()
        {
            return RomeExit(handle);
        }

        /* UTILITY METHODS */


        /* EXTERN REFERENCES TO ROMEAPI.DLL */
        // see https://docs.microsoft.com/en-us/dotnet/standard/native-interop/pinvoke


        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern IntPtr RomeInit(IntPtr args);
        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern int RomeGetScienceVersion(IntPtr args);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern IntPtr RomeGetDatabase(IntPtr handle);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern bool RomeDatabaseOpen(IntPtr handle, IntPtr path);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern bool RomeDatabaseClose(IntPtr handle, IntPtr dbNameIsIgnoredByR2);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern IntPtr RomeGetFiles(IntPtr handle);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern IntPtr RomeFilesOpen(IntPtr handle, IntPtr r2FakePathPtr, int flags);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static unsafe extern IntPtr RomeGetEngine(IntPtr handle);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern void RomeFileClose(IntPtr fileHandle);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern void RomeFilesClose(IntPtr fileHandle, int flags = 0);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern void RomeFilesCloseAll(IntPtr filesHandle, int flags = 0);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern bool RomeEngineRun(IntPtr engineHandle); // uses internal engine pointer

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern bool RomeEngineGetAutorun(IntPtr engineHandle); // uses internal engine pointer

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern void RomeEngineSetAutorun(IntPtr engineHandle, bool autoRun); // uses internal engine pointer

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern IntPtr RomeGetTitle(IntPtr handle, IntPtr key);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern IntPtr RomeFileGetAttr(IntPtr fileHandle, IntPtr attrName);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern int RomeFileGetAttrSize(IntPtr fileHandle, IntPtr attrName);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern IntPtr RomeFileGetAttrValue(IntPtr fileHandle, IntPtr attrName, int index);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern int RomeFileSetAttrValue(IntPtr fileHandle, IntPtr attrName, IntPtr value, int index);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern int RomeFileFileSetAttrSize(IntPtr fileHandle, IntPtr attrName, int newSize);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern int RomeFileGetAttrSizeEx(IntPtr fileHandle, IntPtr attrName);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern IntPtr RomeGetPropertyStr(IntPtr handle, int propertyID);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern IntPtr RomeGetLastError(IntPtr handle);

        [DllImport(@"RomeDLL.dll", CharSet = CharSet.Unicode, SetLastError = true, CallingConvention=CallingConvention.Cdecl)]
        private static extern bool RomeExit(IntPtr handle);
    }
}